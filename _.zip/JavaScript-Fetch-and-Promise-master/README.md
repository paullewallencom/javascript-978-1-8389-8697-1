## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/javascript-fetch-and-promise-video/9781838986971)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# JavaScript-Fetch-and-Promise
Code Repository for JavaScript: Fetch and Promise, published by Packt
